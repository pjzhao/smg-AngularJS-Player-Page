'use strict';

angular.module('userpageApp')
.controller('NavCtrl', ['$rootScope', '$scope', '$location', 'Auth', function ($rootScope, $scope, $location, Auth) {
    $scope.user = Auth.user;
    $scope.userRole = Auth.userRoles;
    $scope.accesslevels = Auth.accesslevels;

    $scope.logout = function () {
        Auth.logout(function(){
            $location.path('/login.html');
        }, function(){
            $rootScope.error ="Failed to log out!";
        });
    };
}]);

angular.module('userpageApp')
.controller('LoginCtrl',
['$rootScope', '$scope', '$location','Auth', function ($rootScope, $scope, $location, $window, Auth) {

    $scope.rememberme = true;
    $scope.login = function () {
        Auth.login({
            email: $scope.email,
            password: $scope.password,
            rememberme: $scope.rememberme
        },
            function (res) {
                $location.path('/');
            },
            function (err) {
                $rootScope.error = "Failed to login";
            });
    };
}]);

angular.module('userpageApp')
.controller('RegisterCtrl',
['$rootScope', '$scope', '$location', 'Auth', function ($rootScope, $scope, $location, Auth) {
    //$scope.role = Auth.userRoles.user;
    //$scope.userRoles = Auth.userRoles;

    $scope.register = function () {
        Auth.register({
            email: $scope.emal,
            password: $scope.password,
        },
            function () {
                $location.path('/');
            },
            function (err) {
                $rootScope.error = err;
            });
    };
}]);