"use strict";

var userpageApp = angular.module("userpageApp", [
    "ngRoute",
    "ngCookies"
]);

userpageApp.config(["$routeProvider", "$locationProvider",
  function($routeProvider, $locationProvider) {
    $locationProvider.html5Mode(true);
    //the templateUrl needs to be changed according to the ABSOLUTE file location -- Pinji
    $routeProvider.
    when("/register", {
        templateUrl: "/login/login/app/partials/register.html",
        controller: "RegisterCtrl"
    }).
    when("/login", {
        templateUrl: "/login/login/app/partials/login.html",
        controller: "LoginCtrl"
    }).
    otherwise({
        redirectTo: "/login"
    });
}]);